# -*- coding: utf-8 -*-

from .checkpoint import load_checkpoint

__all__ = ['load_checkpoint']
